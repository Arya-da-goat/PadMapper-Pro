package com.padmapper.pro;
import android.accessibilityservice.*;import android.graphics.Path;import android.view.*;import android.view.accessibility.AccessibilityEvent;
public class MapperAccessibilityService extends AccessibilityService{
 public void onAccessibilityEvent(AccessibilityEvent e){} public void onInterrupt(){}
 protected boolean onKeyEvent(KeyEvent e){if(e.getAction()!=KeyEvent.ACTION_DOWN||e.getRepeatCount()>0)return true;switch(e.getKeyCode()){case KeyEvent.KEYCODE_BUTTON_A:tap(.80f,.70f);return true;case KeyEvent.KEYCODE_BUTTON_B:tap(.90f,.70f);return true;case KeyEvent.KEYCODE_BUTTON_X:tap(.80f,.60f);return true;case KeyEvent.KEYCODE_BUTTON_Y:tap(.90f,.60f);return true;default:return false;}}
 void tap(float x,float y){int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(w*x,h*y);dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,50)).build(),null,null);}
}